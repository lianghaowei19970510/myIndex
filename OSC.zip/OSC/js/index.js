$(function () {
 // 头部语言切换
 $('.last_item span').on("click", function() {
    $(this).addClass('change').siblings().removeClass('change');
  });
  // 顶部轮播图
  var mySwiper = new Swiper('.top_swiper', {
    autoplay: 3000,
    loop: true,
    autoplayDisableOnInteraction: false,
    pagination: '.bottom_pagination'
  });
  // 视频播放
  $('.look_video').on('click', function(){
    $('.box_video')[0].play();
  })
  function playVideo () {
    var video = $(".box_video");
    if(video.length>0){
        video[0].play();
    }
  }
  // 落地应用轮播图
  var _w = document.documentElement.clientWidth;
  if (_w <= 768) {
    $('.apply_wrap').addClass('apply_wrap2');
  } else {
    $('.apply_wrap').addClass('apply_wrap1');
  }
  var mySwiper = new Swiper('.appli_swiper',{
  autoplay: 3000,
  loop: true,
  autoplayDisableOnInteraction: false,
  slidesPerView : _w <= 768 ? 1 : 3,
  spaceBetween : 20,
  pagination: '.appli_pagination',
  centeredSlides: true
  //spaceBetween : '10%',按container的百分比
  });
  // hover事件
  $('.item_box').on("mouseenter", function() {
    $(this).find('.bg_box').addClass('active_change');
    $(this).find('.f_txt').css('color', '#000');
    $(this).find('.bg_box').children('.old').hide();
    $(this).find('.bg_box').children('.new').show();
    // $(this).find('.bg_box').children('.old').css('display', 'none');
    // $(this).find('.bg_box').children('.new').css('display', 'block');
  });
  $('.item_box').on("mouseleave", function() {
    $(this).find('.bg_box').removeClass('active_change');
    $(this).find('.f_txt').css('color', '#666');
    $(this).find('.bg_box').children('.old').show();
    $(this).find('.bg_box').children('.new').hide();
    // $(this).find('.bg_box').children('.old').css('display', 'block');
    // $(this).find('.bg_box').children('.new').css('display', 'none');
  });
  // 新闻出现
  var arr = [
    {
      time: '123',
      title: '123',
      content: '213'
    },
    {
      time: '123',
      title: '123',
      content: '213'
    },
    {
      time: '123',
      title: '123',
      content: '213'
    },
    {
      time: '123',
      title: '123',
      content: '213'
    },
    {
      time: '123',
      title: '123',
      content: '213'
    },
    {
      time: '123',
      title: '123',
      content: '213'
    }
  ];
  $('.n_item_box').on('click', function(){
    // $('.detail_wrap').css('display', 'block');
    var index = $(this).index();
    $('#_wrap').css('display', 'block');
    if (index%2===0) {
      $('.odd_detail').css('display', 'block');
    } else {
      $('.even_detail').css('display', 'block');
    }
    arr[index];
  })
  // 新闻详情消失
  $('.detail_wrap .close').on('click', function() {
    $('.detail_wrap').css('display', 'none');
    $('#_wrap').css('display', 'none');
  });
  // 团队动画
  $('.item_people').on('mouseenter', function () {
    $(this).find('.team_descrip').toggleClass('active_descrip');
  });
  $('.item_people').on('mouseleave', function () {
    $(this).find('.team_descrip').removeClass('active_descrip');
  });
  // 核心优势
  if (_w <= 768) {
    $('#core_box .pic').css('display', 'none');
  } else {
    $('#core_box .pic').css('display', 'block');
  }
   //手机端nav
   $('.select_nav').click(function (){
    if ($('.nav').css('display') === 'none') {
      $('.nav').fadeIn();
      $('.select_nav>span').addClass('select_nav_active');
    } else {
      $('.nav').fadeOut();
      $('.select_nav>span').removeClass('select_nav_active');
    }
  });
  $('.nav_item').click(function () {
    var _width = document.documentElement.clientWidth;
    if (_width <= 768) {
      $('.nav').fadeOut();
      $('.select_nav>span').removeClass('select_nav_active');
    }
  });
  if (_w <= 768) {
    // 点击其他导航消失
    $('.select_nav').mouseleave(function () {
      $('.nav').fadeOut();
      $('.select_nav>span').removeClass('select_nav_active');
    });
    // 滚动时页面消失
    var winHeight = $(document).scrollTop();
    $(window).scroll(function() {
    var scrollY = $(document).scrollTop();// 获取垂直滚动的距离，即滚动了多少
      if (scrollY > 50) {
        $('.nav').fadeOut();
        $('.select_nav>span').removeClass('select_nav_active');
      }
    });
  }
})