$(function () {
  //右下角获取滚动条高度
  $(window).scroll(function() {
    var s = $(document).scrollTop();
    if (s >= 1500) {
      $("#back_top").css("display", "block");
    } else {
      $("#back_top").css("display", "none");
    }
  });
  //右下角回顶部
  $("#back_top").on("click", function() {
    $("html,body").animate({ scrollTop: 0 }, 500);
  });
})